package com.macys.cyclecount;

import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.Mutation;

public class InvScanEpcToMutationFn extends DoFn<KV<String, Row>, Mutation> {

  private static final Logger LOG = LoggerFactory.getLogger(InvScanEpcToMutationFn.class);
  /**
  * 
  */
  private static final long serialVersionUID = 1L;

  @ProcessElement
  public void processElement(ProcessContext c) {
    final Row inputRow = c.element().getValue();
    final long scnGrpId = Long.parseLong(inputRow.getString("INV_SCAN_GRP_ID"));
    final long hdrId = Long.parseLong(inputRow.getString("INV_SCAN_HDR_ID"));
    long skuUpcNmbr = 0;
    try {
      skuUpcNmbr = Long.parseLong(inputRow.getString("SKU_UPC_NBR"));
    } catch (final Exception e) {
      LOG.error("SKU UPC Number Invalid");
    }
    final com.google.cloud.Timestamp scanTs = com.google.cloud.Timestamp
        .parseTimestamp(inputRow.getString("SCAN_TS"));
    final Mutation scanDataMutation = Mutation.newInsertOrUpdateBuilder("InvScanEpc")
        .set("InvScanGrpID").to(scnGrpId).set("EpcHex").to(inputRow.getString("EPC_HEX"))
        .set("DeptNbr").to(inputRow.getString("DEPT_NBR")).set("EpcUrn")
        .to(inputRow.getString("EPC_URN")).set("InvScanHdrID").to(hdrId).set("RunID").to(0)
        .set("ScanTS").to(scanTs).set("SkuUpcNbr").to(skuUpcNmbr).set("UserID")
        .to(inputRow.getString("USER_ID")).set("VndNbr").to(inputRow.getString("VND_NBR")).build();
    c.output(scanDataMutation);
  }

}
