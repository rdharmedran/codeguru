package com.macys.cyclecount;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.beam.sdk.transforms.DoFn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.api.core.ApiFunction;
import com.google.api.gax.retrying.RetrySettings;
import com.google.api.gax.rpc.UnaryCallSettings.Builder;
import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.KeySet;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.SpannerOptions;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import org.threeten.bp.Duration;

public class EpcTestDataCleaner extends DoFn<String,Mutation> {

  private static final Logger LOG = LoggerFactory.getLogger(EpcTestDataCleaner.class);
  private static final String TEST_DATA_QUERY = "delete * from FROM invscanepc ";
  private Spanner spanner = null;
  private DatabaseClient dbClient = null;
  Properties configProperties = null;

  public EpcTestDataCleaner() {
    try {
      configProperties = RFIDCycleCountUtil.readPropertiesFile();
    } catch (final IOException e) {
      LOG.error("Error reading configuration file::" + e);
    }
  }

  @StartBundle
  public void startBundle(StartBundleContext c) throws Exception {
    final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
        .newBuilder().build();
    
    final String spannerProjectID = configProperties.getProperty("gcp.project.id");
    final String spannerInstanceID = configProperties.getProperty("sink.spanner.instance.id");
    final String spannerDatabaseID = configProperties.getProperty("sink.spanner.database.id");
    final RetrySettings retrySettings =
        RetrySettings.newBuilder()
            .setInitialRpcTimeout(Duration.ofMinutes(60L))
            .setMaxRpcTimeout(Duration.ofMinutes(60L))
            .setMaxAttempts(1)
            .setTotalTimeout(Duration.ofMinutes(60L))
            .build();
    SpannerOptions.Builder builder =
        SpannerOptions.newBuilder()
            .setProjectId(spannerProjectID);
    builder
        .getSpannerStubSettingsBuilder()
        .applyToAllUnaryMethods(
            new ApiFunction<com.google.api.gax.rpc.UnaryCallSettings.Builder<?, ?>, Void>() {
            
            
              @Override
              public Void apply(Builder<?, ?> input) {
                // TODO Auto-generated method stub
                input.setRetrySettings(retrySettings);
                return null;
              }
            });
    builder
        .getSpannerStubSettingsBuilder()
        .executeStreamingSqlSettings()
        .setRetrySettings(retrySettings);
    builder
        .getSpannerStubSettingsBuilder()
        .streamingReadSettings()
        .setRetrySettings(retrySettings);

    Spanner spanner = builder.build().getService();
  
    
    
    
    
    
    
    
 //   spanner = spannerOptions.getService();

  
    final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
    dbClient = spanner.getDatabaseClient(db);
  }

  @FinishBundle
  public void finishBundle(FinishBundleContext c) {
    try {
      dbClient = null;
      spanner.close();
    } catch (final Exception e) {
      LOG.error("error while loading lookup>>>>>>>>>>>>>>>>>>>>>>>>>", e);
    }
  }

  @ProcessElement
  public void processElement(ProcessContext context) {
    final MyOptions ops = context.getPipelineOptions().as(MyOptions.class);
    // final String grpIdList = ops.getSrcGrpId().get();
    // final String hdrIdList = ops.getSrcHeaderId().get();
    final String storeId = ops.getStoreId().get();

    List<Mutation> mutations = new ArrayList<>();
    mutations.add(Mutation.delete("invscanepc", KeySet.all()));
    dbClient.write(mutations);
    
 // context.output(Mutation.delete("invscanepc", KeySet.all()));
  
  }

}
