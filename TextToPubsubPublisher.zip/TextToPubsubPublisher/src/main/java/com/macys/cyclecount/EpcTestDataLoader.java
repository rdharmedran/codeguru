package com.macys.cyclecount;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubClient;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubClient.OutgoingMessage;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubClient.TopicPath;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubGrpcClient;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubOptions;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.collect.ImmutableMap;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.google.common.collect.Lists;


public class EpcTestDataLoader extends DoFn<String, PubsubMessage> {

  static Logger LOG = LoggerFactory.getLogger("jsonLogger");
  TopicPath topic = null;

  Properties configProperties = null;
  private PubsubClient pubsubClient;

  public EpcTestDataLoader() {
    try {
      configProperties = RFIDCycleCountUtil.readPropertiesFile();
    } catch (final IOException e) {
      LOG.error("Error reading configuration file::" + e);
    }
  }

  @StartBundle
  public void startBundle(StartBundleContext c) throws IOException {
   
  
   
  }

  @FinishBundle
  public void finishBundle(FinishBundleContext c) {
   
  }

  @ProcessElement
  public void processElement(ProcessContext context) throws IOException {
    
   
    
        final String testData = context.element();
        final String[] testDataArray = testData.split(",");
      
          final String jsonString = "{\"groupId\":\"" +testDataArray[0]
              + "\",\"scanSessionId\":\"" + testDataArray[1] + "\",\"userId\":\""
              + "BH16171" + "\",\"actionRequest\":\"" +"start-scan"
             + "\"}";
              
       LOG.info(jsonString);
          final PubsubMessage mesg = new PubsubMessage(jsonString.getBytes(),
              ImmutableMap.of("UNIQUE_ID", testDataArray[0] + testDataArray[1]));
         
       //   as.add( OutgoingMessage.of(mesg, DateTime.now().getMillis(), null));
         
        //  if(as.size()>0)
          //  pubsubClient.publish(topic, as );
        //  as.clear();
       context.output(mesg);

       
     
        
      
    

  }
  
}
