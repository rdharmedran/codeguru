package com.macys.cyclecount;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubClient;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubClient.OutgoingMessage;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubClient.TopicPath;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubGrpcClient;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubOptions;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.util.Sleeper;
import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.collect.ImmutableMap;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.google.common.collect.Lists;


public class EpcTestDataLoader123 extends DoFn<String, PubsubMessage> {

  static Logger LOG = LoggerFactory.getLogger("jsonLogger");
  TopicPath topic = null;

  Properties configProperties = null;
  private PubsubClient pubsubClient;

  public EpcTestDataLoader123() {
    try {
      configProperties = RFIDCycleCountUtil.readPropertiesFile();
    } catch (final IOException e) {
      LOG.error("Error reading configuration file::" + e);
    }
  }

  @StartBundle
  public void startBundle(StartBundleContext c) throws IOException {
   
    
   
  }

  @FinishBundle
  public void finishBundle(FinishBundleContext c) {
   
  }

  @ProcessElement
  public void processElement(ProcessContext context) throws IOException {
    
    Sleeper sleeper = Sleeper.DEFAULT;
    
        final String testData = context.element();
        final String[] testDataArray = testData.split(",");
        com.google.cloud.Timestamp scanTs =null;
        try {
       scanTs = com.google.cloud.Timestamp
              .parseTimestamp(testDataArray[6].toString());
        }catch(Exception e) {
          scanTs = com.google.cloud.Timestamp.now();
        }
        if(isNumeric(testDataArray[3])) {
          final String jsonString = "{\"INV_SCAN_GRP_ID\":\"" +testDataArray[3]
              + "\",\"INV_SCAN_HDR_ID\":\"" + testDataArray[4] + "\",\"USER_ID\":\""
              + testDataArray[7] + "\",\"EPC_HEX\":\"" + testDataArray[8]
              + "\",\"EPC_URN\":\"" + testDataArray[2] + "\",\"SKU_UPC_NBR\":\""
              + testDataArray[5] + "\",\"SCAN_TS\":\"" + scanTs + "\"}";
          try {
            sleeper.sleep(2);
            LOG.info("sleeing for 10 ms");
          } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          }
         LOG.info(jsonString);
          final PubsubMessage mesg = new PubsubMessage(jsonString.getBytes(),
              ImmutableMap.of("UNIQUE_ID", testDataArray[4] + testDataArray[8]));
         
       //   as.add( OutgoingMessage.of(mesg, DateTime.now().getMillis(), null));
         
        //  if(as.size()>0)
          //  pubsubClient.publish(topic, as );
        //  as.clear();
       context.output(mesg);

        }
     
        
      
    

  }
  
  public static boolean isNumeric(String strNum) {
    if (strNum == null) {
        return false;
    }
    try {
        double d = Double.parseDouble(strNum);
    } catch (NumberFormatException nfe) {
        return false;
    }
    return true;
}
  
}
