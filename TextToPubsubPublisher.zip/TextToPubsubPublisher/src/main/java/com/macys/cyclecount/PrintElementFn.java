package com.macys.cyclecount;

import java.util.Comparator;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.state.BagState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PrintElementFn extends DoFn<PubsubMessage,PubsubMessage> {

  private static final Logger LOG = LoggerFactory.getLogger(PrintElementFn.class);

  // @StateId("Value")
  // private final StateSpec<MapState<String, Long>> mapState = StateSpecs.map();
 

  @ProcessElement
	public void processElement(ProcessContext c) {
		
		
	LOG.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>. Attribute:: "
   + c.element());

c.output(c.element());
  }
}
