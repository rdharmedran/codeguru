package com.macys.cyclecount;

import java.io.IOException;
import java.util.Properties;

import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

import ch.qos.logback.classic.LoggerContext;

public class EpcTestDataRunIdLoader extends DoFn<String, Row> {

  static Logger LOG = LoggerFactory.getLogger("jsonLogger");
  // private static final String TEST_DATA_QUERY = "SELECT count( *) as count,ps.DeptNbr, ps.VndNbr
  // FROM EpcTestData dvn join prodsku ps on (ps.ZlDivnNbr = 71 and ps.skuupcnbr = dvn.skuupcnbr)
  // where dvn.zlStorenbr=%1$s group by ps.DeptNbr, ps.VndNbr order by count desc";

  private static final String TEST_DATA_QUERY = "select DeptNbr,VndNbr from TargetCntByDVN where ZlStoreNbr=3 and ZoneName=\"RTW\"";
  private Spanner spanner = null;
  private DatabaseClient dbClient = null;
  Properties configProperties = null;
  Schema enrichedMessageSchema = Schema.builder().addInt64Field("DEPT_NBR")
      .addInt64Field("VND_NBR")
      .build();

  public EpcTestDataRunIdLoader() {
    try {
      configProperties = RFIDCycleCountUtil.readPropertiesFile();
    } catch (final IOException e) {
      LOG.error("Error reading configuration file::" + e);
    }
  }

  @StartBundle
  public void startBundle(StartBundleContext c) {
    final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
        .newBuilder().build();
    spanner = spannerOptions.getService();

    final String spannerProjectID = configProperties.getProperty("gcp.project.id");
    final String spannerInstanceID = configProperties.getProperty("spanner.instance.id");
    final String spannerDatabaseID = configProperties.getProperty("spanner.database.id");
    final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
    dbClient = spanner.getDatabaseClient(db);
  }

  @FinishBundle
  public void finishBundle(FinishBundleContext c) {
    try {
      dbClient = null;
      spanner.close();
    } catch (final Exception e) {
      LOG.error("error while loading lookup>>>>>>>>>>>>>>>>>>>>>>>>>", e);
    }
  }

  @ProcessElement
  public void processElement(ProcessContext context) {
    final MyOptions ops = context.getPipelineOptions().as(MyOptions.class);
    // final String grpIdList = ops.getSrcGrpId().get();
    // final String hdrIdList = ops.getSrcHeaderId().get();
    final String storeId = ops.getStoreId().get();
    final Statement stmtTogetDisplayEpc = Statement.newBuilder(String.format(TEST_DATA_QUERY, "3"))
        .build();
    LOG.info("Test Data Loading >>>>>>>>>>>>>>>>>>>>>>" + stmtTogetDisplayEpc.toString());
    final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
        .executeQuery(stmtTogetDisplayEpc);
    while (resultSet.next()) {

      final Struct testData = resultSet.getCurrentRowAsStruct();
      final String id = testData.getLong("DeptNbr") + "_" + testData.getLong("VndNbr");

      context.output(Row.withSchema(enrichedMessageSchema)
          .withFieldValue("DEPT_NBR", testData.getLong("DeptNbr") )
          .withFieldValue("VND_NBR", testData.getLong("VndNbr"))
          .build());

    }
    resultSet.close();
  }

}
