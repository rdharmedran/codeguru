package com.macys.cyclecount;

import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.options.Default;
import org.apache.beam.sdk.options.Description;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.ValueProvider;

public interface MyOptions extends DataflowPipelineOptions{

  @Description("headerList")
  @Default.String("102115_102234")
  ValueProvider<String> getHeaderList();

  void setSrcGrpId(ValueProvider<String> value);

  ValueProvider<String> getSrcGrpId();

  void setSrcHeaderId(ValueProvider<String> value);

  ValueProvider<String> getSrcHeaderId();

  void setSinkGrpId(ValueProvider<String> value);

  ValueProvider<String> getSinkGrpId();

  void setStoreId(ValueProvider<String> value);

  ValueProvider<String> getStoreId();

  void setSinkHeaderId(ValueProvider<String> value);

  ValueProvider<String> getSinkHeaderId();

  void setHeaderList(ValueProvider<String> value);

  void setUserId(ValueProvider<String> value);

  ValueProvider<String> getUserId();
  
  void setPath(ValueProvider<String> value);

  ValueProvider<String> getPath();

  @Description("topic")
  @Default.String("projects/mtech-storesys-np/topics/cycle-count-filter-count-rfid-np-dev")
  ValueProvider<String> getTopic();

  void setTopic(ValueProvider<String> value);
}
