package com.macys.cyclecount;

import static java.util.stream.Collectors.toList;
import static org.apache.beam.sdk.util.RowJsonUtils.newObjectMapperWith;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Nullable;

import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.Element;
import org.apache.beam.sdk.transforms.DoFn.MultiOutputReceiver;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.Timestamp;
import org.apache.beam.sdk.util.RowJsonUtils;
import org.apache.beam.sdk.util.RowJson.RowJsonDeserializer;
import org.apache.beam.sdk.util.RowJson.UnsupportedRowJsonException;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TupleTag;
import org.joda.time.Instant;

import com.fasterxml.jackson.databind.ObjectMapper;

 public class PubsubMessageToRoW extends DoFn<PubsubMessage, Row> {
	  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static final String TIMESTAMP_FIELD = "event_timestamp";
	  static final String ATTRIBUTES_FIELD = "attributes";
	  static final String PAYLOAD_FIELD = "payload";
	  static final TupleTag<PubsubMessage> DLQ_TAG = new TupleTag<PubsubMessage>() {};
	  static final TupleTag<Row> MAIN_TAG = new TupleTag<Row>() {};

    private final Schema messageSchema;

    private final Schema payloadSchema;

    private final boolean useDlq;

    private transient volatile @Nullable ObjectMapper objectMapper;

    protected PubsubMessageToRoW(Schema messageSchema, boolean useDlq) {
      this.messageSchema = messageSchema;
      // Construct flat payload schema.
      this.payloadSchema =
          new Schema(
              messageSchema.getFields().stream()
                  .filter(f -> !f.getName().equals(TIMESTAMP_FIELD))
                  .collect(Collectors.toList()));
      this.useDlq = useDlq;
    }

    /**
     * Get the value for a field from a given payload in the order they're specified in the flat
     * schema.
     */
    private Object getValueForFieldFlatSchema(Schema.Field field, Instant timestamp, Row payload) {
      String fieldName = field.getName();
      if (TIMESTAMP_FIELD.equals(fieldName)) {
        return timestamp;
      } else {
        return payload.getValue(fieldName);
      }
    }

    private Row parsePayload(PubsubMessage pubsubMessage) {
      String payloadJson = new String(pubsubMessage.getPayload(), StandardCharsets.UTF_8);
      if (objectMapper == null) {
        objectMapper = newObjectMapperWith(RowJsonDeserializer.forSchema(payloadSchema));
      }

      return RowJsonUtils.jsonToRow(objectMapper, payloadJson);
    }

    @ProcessElement
    public void processElement(
        @Element PubsubMessage element, @Timestamp Instant timestamp,ProcessContext c) {
      try {
        Row payload = parsePayload(element);
        List<Object> values =
            messageSchema.getFields().stream()
                .map(field -> getValueForFieldFlatSchema(field, timestamp, payload))
                .collect(toList());
        c.output(Row.withSchema(messageSchema).addValues(values).build());
      } catch (UnsupportedRowJsonException jsonException) {
        
      }
    }
  }


