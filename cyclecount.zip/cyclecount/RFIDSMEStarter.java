package com.macys.cyclecount;

/*

* Licensed to the Apache Software Foundation (ASF) under one

* or more contributor license agreements.  See the NOTICE file

* distributed with this work for additional information

* regarding copyright ownership.  The ASF licenses this file

* to you under the Apache License, Version 2.0 (the

* "License"); you may not use this file except in compliance

* with the License.  You may obtain a copy of the License at

*

*     http://www.apache.org/licenses/LICENSE-2.0

*

* Unless required by applicable law or agreed to in writing, software

* distributed under the License is distributed on an "AS IS" BASIS,

* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

* See the License for the specific language governing permissions and

* limitations under the License.

*/
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.extensions.sql.SqlTransform;
import org.apache.beam.sdk.extensions.sql.meta.provider.pubsub.PubsubMessageToRow;
import org.apache.beam.sdk.io.AvroIO;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;

import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.redis.RedisIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.state.ValueState;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.Deduplicate;
import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.transforms.join.CoGbkResult;
import org.apache.beam.sdk.transforms.join.CoGroupByKey;
import org.apache.beam.sdk.transforms.join.KeyedPCollectionTuple;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.windowing.AfterFirst;
import org.apache.beam.sdk.transforms.windowing.AfterPane;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.CalendarWindows;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Trigger;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.PDone;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.DateTimeZone;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.google.common.collect.MapMaker;
import com.macys.cyclecount.async.SpannerWriteDoFn;

/**
 * 
 * RFID Scanning Dataflow to read data from pubsub and write data
 *
 *
 * 
 * 
 * 
 */
public class RFIDSMEStarter {
	private static final String DDD = "\"ddd\"";

	private static final String EXIT_TRAN_REF_NBR2 = "ExitTranRefNbr2";

	private static final String EXIT_TRAN_REF_NBR1 = "ExitTranRefNbr1";

	private static final String SCAN_TS = "ScanTS";

	private static final String SALES_UNITS = "SalesUnits";

	private static final String REMAINING_UNITS = "RemainingUnits";

	private static final String LINE_SEQ_NBR = "LineSeqNbr";

	private static final String TRAN_NBR = "TranNbr";

	private static final String REG_NBR = "RegNbr";

	private static final String TRAN_DATE = "TranDate";

	private static final String TRAN_TS = "TranTS";

	private static final String SKU_UPC_NBR = "SkuUpcNbr";

	private static final String ZL_STORE_NBR = "ZlStoreNbr";

	private static final String ZL_DIVN_NBR = "ZlDivnNbr";

	private static final String COMPARE_QUERY = "SELECT CALLS.* FROM CALLS WHERE NOT EXISTS (SELECT 1 FROM STATIONS where CALLS.ZlDivnNbr = STATIONS.ZlDivnNbr and  CALLS.ZlStoreNbr = STATIONS.ZlStoreNbr and CALLS.SkuUpcNbr = STATIONS.SkuUpcNbr)";

	private static final String GROUP_COUNT_SQL = "select epc.InvScanHdrID, count(1) as groupCount from InvScanEpc epc , invscanhdr hdr where  hdr.invScanhdrId = epc.invscanhdrid and hdr.invscanhdrstatus = 'Scanning'  group by epc.InvScanHdrID";

	private static final String TOTAL_COUNT_QUERY = "select InvScanHdrID,count(*) as totalCount from InvScanEpc where InvScanHdrID = @inscanHeaderId group by InvScanHdrID";

	private static final String GROUP_COUNT_QUERY = "select InvScanHdrID,count(*) as actualCount from InvScanEpc where InvScanHdrID = @inscanHeaderId   group by InvScanHdrID";

	private static final String DISPLAY_TAG_QUERY = "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733  and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ";

	private static final String DVN_LOOKUP_QUERY = "select InvScanGrpId , ps.skuupcnbr, dvn.deptnbr, dvn.vndnbr from InvScanGrp grp join targetCntByDVN dvn on (dvn.ZlDivnNbr = grp.ZlDivnnbr and dvn.ZlStoreNbr = grp.ZlStoreNbr and dvn.CountDate = grp.CountDate) join prodsku ps on (ps.ZlDivnNbr = dvn.ZldivnNbr and ps.DeptNbr = dvn.DeptNbr and ps.VndNbr = dvn.vndnbr  and skuupcnbr in UNNEST( @skuUpcNbr) ) where grp.invscangrpid = @invScanGrpId ";

	private static final Logger LOG = LoggerFactory.getLogger(RFIDSMEStarter.class);

	public static void main(String[] args) throws Exception {

		/* .................Loading configuration starts ................ */
		Properties configProperties = null;
		try {
			configProperties = RFIDCycleCountUtil.readPropertiesFile();
		} catch (IOException e) {
			LOG.error("Error reading configuration file::" + e);
		}
		PipelineOptions options = PipelineOptionsFactory.create();

		/* .................Loading configuration ends ................ */

		final String SPANNER_PROJECT_ID = configProperties.getProperty("gcp.project.id");
		final String SPANNER_INSTANCE_ID = configProperties.getProperty("spanner.instance.id");
		final String SPANNER_DATABASE_ID = configProperties.getProperty("spanner.database.id");
		Pipeline rfidScanPipeline = Pipeline.create(options);
		LOG.info("Pipeline started");

		/* .................Schema declarations starts ................ */
		Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
				.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN")
				.addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
		Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
				.addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
				.addStringField("EPC_URN").addStringField("DEPT_NBR").addStringField("VND_NBR")
				.addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();

		Schema notificationSchema = Schema.builder().addInt64Field("scanSessionId").addStringField("actionRequest")
				.addStringField("userId").build();

		final Schema rfidScanVendorKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
				.addStringField("DEPT_NBR").addStringField("VND_NBR").build();
		final Schema test = Schema.builder().addStringField("INV_SCAN_HDR_ID").addStringField("count").build();
		final Schema rfidScanVendorSKUCountSchema = Schema.builder().addStringField("DEPT_NBR")
				.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("INV_SCAN_GRP_ID").build();
		/* .................... Schema declarations ends ................ */

		Schema SmartExitEpcStgSchema = Schema.builder()

				.addStringField(ZL_DIVN_NBR).addStringField(ZL_STORE_NBR)// int

				.addStringField(SKU_UPC_NBR)

				.addInt64Field(SCAN_TS)

				.build();

		Schema smartExitEpcDtlFetchSchema = Schema.builder()

				.addStringField(ZL_DIVN_NBR).addStringField(ZL_STORE_NBR)// int

				.addStringField(SKU_UPC_NBR)

				.addStringField("ExitTranDate")

				.addInt64Field(SCAN_TS)

				.addStringField("ShrinkFlag").addStringField("ProcStatusFlag")

				.addStringField("ExitTranSource")

				.addStringField(EXIT_TRAN_REF_NBR1).addStringField(EXIT_TRAN_REF_NBR2).addStringField("ExitTranRefNbr3")
				.addStringField("ExitTranRefNbr4")

				.addStringField("LastUpdTS")

				// .addStringField("LastUpdUser")

				.build();

		Schema postranSchema = Schema.builder()

				.addStringField(ZL_DIVN_NBR).addStringField(ZL_STORE_NBR)// int

				.addStringField(SKU_UPC_NBR)

				.addStringField(TRAN_DATE)// date

				.addInt64Field(TRAN_TS)// timestamp

				.addStringField(REG_NBR).addStringField(TRAN_NBR).addStringField(LINE_SEQ_NBR)

				.addStringField(REMAINING_UNITS).addStringField(SALES_UNITS)

				.build();

		Schema joinsmartExitEpcDtlFetchSchema = Schema.builder()

				.addStringField(ZL_DIVN_NBR).addStringField(ZL_STORE_NBR)// int

				.addStringField(SKU_UPC_NBR)

				.addStringField("ExitTranDate")
				.addInt64Field(TRAN_TS)// timestamp
				.addInt64Field(SCAN_TS)

				.addStringField("ShrinkFlag").addStringField("ProcStatusFlag")

				.addStringField("ExitTranSource")

				.addStringField(EXIT_TRAN_REF_NBR1).addStringField(EXIT_TRAN_REF_NBR2).addStringField("ExitTranRefNbr3")
				.addStringField("ExitTranRefNbr4")

				.addStringField("LastUpdTS")

				.addStringField("station_sku")

				// .addStringField("LastUpdUser")

				.build();

		/* SmartExitEpcstagingData Collection */

		PCollection<KV<Row, Row>> rfidSmartExitstage = rfidScanPipeline
				.apply(SpannerIO.read().withInstanceId(SPANNER_INSTANCE_ID)

						.withDatabaseId(SPANNER_DATABASE_ID).withBatching(false)

						.withQuery("SELECT ZlDivnNbr,ZlStoreNbr,SkuUpcNbr,ScanTS,"

								+ "FROM SmartExitEpcStg limit 600 "))

				.apply(ParDo.of(new DoFn<Struct, KV<Row, Row>>() {

					@ProcessElement

					public void processElement(ProcessContext context) {

						Struct struct = context.element();

						String ZlDivnNbr = new Long(struct.getLong(ZL_DIVN_NBR)).toString();

						String ZlStoreNbr = new Long(struct.getLong(ZL_STORE_NBR)).toString();

						String skuUpc = new Long(struct.getLong(SKU_UPC_NBR)).toString();

						String ScanTS = (struct.getTimestamp(SCAN_TS)).toString();
						Long longvalue=struct.getTimestamp(SCAN_TS).getSeconds();

						String jsonString = "{\"ZlDivnNbr\":\"" + ZlDivnNbr + "\",\"ZlStoreNbr\":\"" + ZlStoreNbr
								+ "\","

								+ "\"SkuUpcNbr\":\"" + skuUpc + "\",\"ScanTS\":\"" + ScanTS + "\" }";

						 LOG.info(jsonString);


						// LOG.debug(jsonString);
						 
						 context.output(KV.of(Row.withSchema(SmartExitEpcStgSchema)
									
									.withFieldValue("ZlDivnNbr",ZlDivnNbr)									
									.withFieldValue("ScanTS",longvalue)
									.withFieldValue("ZlStoreNbr", ZlStoreNbr)
									.withFieldValue("SkuUpcNbr",skuUpc)
									
									.build(),Row.withSchema(SmartExitEpcStgSchema)
									
									.withFieldValue("ZlDivnNbr",ZlDivnNbr)									
									.withFieldValue("ScanTS",longvalue)
									.withFieldValue("ZlStoreNbr", ZlStoreNbr)
									.withFieldValue("SkuUpcNbr",skuUpc)
									
									.build()));
						 

						


					}

				}));
				
		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorSKUDataaGroupedRecords7 = rfidSmartExitstage
				.setCoder(KvCoder.of(RowCoder.of(SmartExitEpcStgSchema), RowCoder.of(SmartExitEpcStgSchema)))
				.apply(GroupByKey.<Row, Row>create());
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/* SmartExitEpcDtlData Collection */

//		PCollection<Row> rfidSmartExitDetail = rfidScanPipeline.apply(SpannerIO.read()
//				.withInstanceId(SPANNER_INSTANCE_ID)
//
//				.withDatabaseId(SPANNER_DATABASE_ID).withBatching(false)
//
//				.withQuery("SELECT ZlDivnNbr,ZlStoreNbr,SkuUpcNbr,ScanTS,"
//
//						+ "ExitTranRefNbr1,ExitTranRefNbr2,ExitTranRefNbr3,ExitTranRefNbr4,"
//
//						+ "ExitTranDate,ShrinkFlag,ProcStatusFlag,ExitTranSource,LastUpdTS FROM SmartExitEpcDtl  limit 600 "))
//
//				.apply(ParDo.of(new DoFn<Struct, String>() {
//
//					@ProcessElement
//
//					public void processElement(ProcessContext context) {
//
//						Struct struct = context.element();
//
//						String ZlDivnNbr = new Long(struct.getLong(ZL_DIVN_NBR)).toString();
//
//						String ZlStoreNbr = new Long(struct.getLong(ZL_STORE_NBR)).toString();
//
//						String skuUpc = new Long(struct.getLong(SKU_UPC_NBR)).toString();
//
//						String ScanTS = (struct.getTimestamp(SCAN_TS)).toString();
//
//						String ExitTranRefNbr1 = String.valueOf(struct.getLong(EXIT_TRAN_REF_NBR1));
//
//						String ExitTranRefNbr2 = String.valueOf(struct.getLong(EXIT_TRAN_REF_NBR2));
//
//						String ExitTranRefNbr3 = String.valueOf(struct.getLong("ExitTranRefNbr3"));
//
//						String ExitTranRefNbr4 = String.valueOf(struct.getLong("ExitTranRefNbr4"));
//
//						String ExitTranDate = (struct.getDate("ExitTranDate")).toString();
//
//						String ShrinkFlag = (struct.getString("ShrinkFlag"));
//
//						String ProcStatusFlag = (struct.getString("ProcStatusFlag"));
//
//						String ExitTranSource = (struct.getString("ExitTranSource"));
//
//						String LastUpdTS = (struct.getTimestamp("LastUpdTS")).toString();
//
//						String jsonString = "{\"ZlDivnNbr\":\"" + ZlDivnNbr + "\",\"ZlStoreNbr\":\"" + ZlStoreNbr
//								+ "\",\"SkuUpcNbr\":\"" + skuUpc + "\",\"ScanTS\":\"" + ScanTS + "\","
//
//								+ "\"ExitTranDate\":\"" + ExitTranDate + "\",\"ShrinkFlag\":\"" + ShrinkFlag
//								+ "\",\"ProcStatusFlag\":\"" + ProcStatusFlag + "\",\"ExitTranSource\":\""
//								+ ExitTranSource + "\",\"ExitTranRefNbr1\":\"" + ExitTranRefNbr1
//								+ "\",\"ExitTranRefNbr2\":\"" + ExitTranRefNbr2 + "\",\"ExitTranRefNbr3\":\"" +
//
//								ExitTranRefNbr3 + "\",\"ExitTranRefNbr4\":\"" + ExitTranRefNbr4 + "\",\"LastUpdTS\":\""
//								+ LastUpdTS + "\"}";
//
//						// LOG.info(jsonString);
//
//						context.output(jsonString);
//
//					}
//
//				})).apply("JSONToTagsWrittenRow", JsonToRow.withSchema(smartExitEpcDtlFetchSchema))
//				.setRowSchema(smartExitEpcDtlFetchSchema);

		/* PosTransaction Collection */

		PCollectionView<Map<Row, Iterable<Row>>> posTransactionDetail = rfidScanPipeline
				.apply(SpannerIO.read().withInstanceId(SPANNER_INSTANCE_ID)

						.withDatabaseId(SPANNER_DATABASE_ID).withBatching(false)

						.withQuery("SELECT ZlDivnNbr,ZlStoreNbr,SkuUpcNbr,TranTS,TranDate,RegNbr,TranNbr,LineSeqNbr,RemainingUnits,"

								+ "SalesUnits FROM PosTrans limit 1000 "))

				.apply(ParDo.of(new DoFn<Struct, KV<Row, Row>>() {

					@ProcessElement

					public void processElement(ProcessContext context) {

						Struct struct = context.element();

						String ZlDivnNbr = new Long(struct.getLong(ZL_DIVN_NBR)).toString();

						String ZlStoreNbr = new Long(struct.getLong(ZL_STORE_NBR)).toString();

						String skuUpc = new Long(struct.getLong(SKU_UPC_NBR)).toString();

						//String TranTS = (struct.getTimestamp(TRAN_TS)).toString();
						Long longvalue=struct.getTimestamp(TRAN_TS).getSeconds();
						
						String TranDate = (struct.getDate(TRAN_DATE)).toString();

						String RegNbr = new Long(struct.getLong(REG_NBR)).toString();

						String TranNbr = new Long(struct.getLong(TRAN_NBR)).toString();

						String LineSeqNbr = new Long(struct.getLong(LINE_SEQ_NBR)).toString();

						String RemainingUnits = new Long(struct.getLong(REMAINING_UNITS)).toString();

						String SalesUnits = new Long(struct.getLong(SALES_UNITS)).toString();
						
						
						
						
						
						


						// LOG.debug(jsonString);

						context.output(KV.of(Row.withSchema(postranSchema)
								
								.withFieldValue("ZlDivnNbr",ZlDivnNbr)							
								.withFieldValue("ZlStoreNbr", ZlStoreNbr)
								.withFieldValue("SkuUpcNbr",skuUpc).build()
								,Row.withSchema(postranSchema)
								.withFieldValue("LineSeqNbr",LineSeqNbr)
								.withFieldValue("RemainingUnits", RemainingUnits)
								.withFieldValue("SalesUnits",SalesUnits)
								.withFieldValue("ZlDivnNbr",ZlDivnNbr)
								.withFieldValue("TranDate",TranDate)
								.withFieldValue("TranTS",longvalue)
								.withFieldValue("TranNbr",TranNbr)
								.withFieldValue("ZlStoreNbr", ZlStoreNbr)
								.withFieldValue("SkuUpcNbr",skuUpc)
								.withFieldValue("RegNbr",
										RegNbr)
								.build()));

					}

				})).apply(GroupByKey.<Row, Row>create()).apply(View.<Row, Iterable<Row>>asMap());

		

		
		
		
		
		rfidScanVendorSKUDataaGroupedRecords7.apply(ParDo.of(new DoFn<KV<Row, Iterable<Row>>, Row>() {
			private Map<String, Long> displayEpcMap=new HashMap<>();
			@ProcessElement

			public void processElement(ProcessContext c) {
				Row row=c.element().getKey();
				String divNbm=row.getString("ZlDivnNbr");
				String divNbm1=row.getString("ZlStoreNbr");
				String divNbm2=row.getString("SkuUpcNbr");
				Row sideinputRw=Row.withSchema(postranSchema)
				
				.withFieldValue("ZlDivnNbr",divNbm)							
				.withFieldValue("ZlStoreNbr", divNbm1)
				.withFieldValue("SkuUpcNbr",divNbm2).build();
				Map<Row, Iterable<Row>> sideInoput = c.sideInput(posTransactionDetail);
				 Iterable<Row> posRows=sideInoput.get(sideinputRw);
				 Iterable<Row> yellowRows=c.element().getValue();
				Iterator<Row> iterator1= yellowRows.iterator();
				Iterator<Row> iterator2= posRows.iterator();
				final long count = StreamSupport.stream(yellowRows.spliterator(), false).count();
				 while(iterator1.hasNext()) {
					 
					 Row row1=iterator1.next();
					 while(iterator2.hasNext()) {
						 Row row2=iterator2.next();
						 String keyAsString="";
						 if(count==row2.getInt64("remainingCount") && displayEpcMap.get(keyAsString)==null) {
							 c.output(c.element()); 
						 
					 }
					 
				 }
				
				 displayEpcMap.put(row, remappingFunction)
				
					posRows
				LOG.debug("\nCompare Data between stagingSmartExittable and POS table ::" + c.element().toString());
				

			}

		}));

		rfidScanPipeline.run().waitUntilFinish();
	}
}
