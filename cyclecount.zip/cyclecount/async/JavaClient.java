package com.macys.cyclecount.async;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.function.Supplier;

import com.google.common.util.concurrent.*;
import com.macys.cyclecount.RFIDCycleCountStarter7;
import com.macys.cyclecount.RFIDCycleCountUtil;

import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.util.concurrent.MoreExecutors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.Spanner;

public class JavaClient {
	private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleCountStarter7.class);

	
	Properties configProperties = null;

	private Spanner spanner;

	private DatabaseClient dbClient;
	static JavaClient client=null;

	JavaClient() {
		try {
			configProperties = RFIDCycleCountUtil.readPropertiesFile();
		} catch (IOException e) {
			LOG.error("Error reading configuration file::" + e);
		}

		com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions.newBuilder()
				.build();
		spanner = spannerOptions.getService();

		String spannerProjectID = configProperties.getProperty("gcp.project.id");
		String spannerInstanceID = configProperties.getProperty("spanner.instance.id");
		String spannerDatabaseID = configProperties.getProperty("spanner.database.id");
		DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
		dbClient = spanner.getDatabaseClient(db);
	}

	public CompletableFuture<String> request(Mutation mutations) {
		CompletableFuture<String> future = CompletableFuture.supplyAsync(new Supplier<String>() {
		    @Override
		    public String get() {
		    	List a=new ArrayList();
		    	a.add(mutations);
		        dbClient.write(a);
		       // System.out.println("Saved to DB");
				return "success";
		    }
		});
		

return future;
	}
	public static JavaClient getClient() {
		if(client==null){
			client= new JavaClient();
		}
		return client;
	}
}
