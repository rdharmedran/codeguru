package com.macys.cyclecount;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class GMMCountToJsonFn extends DoFn<KV<Row, Iterable<Row>>,String> {
	private static final Logger LOG = LoggerFactory.getLogger(GMMCountToJsonFn.class);
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ProcessElement
	public void processElement(ProcessContext c) {
		LOG.info("\nWriting to GMM Count Pubusb>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>::" );
		   try {
			String jsonString = "{ sessionId:" +c.element().getKey().getString("INV_SCAN_HDR_ID")+",groupId:" +c.element().getKey().getString("INV_SCAN_GRP_ID")
					+ "zoneName:\"\",  remainingCount:\"\",MESSAGE_TYPE:gmm-count,gmmCounts:{" ;
			 Iterable<Row> inputRow1 = c.element().getValue();
			 Iterator<Row> itr=inputRow1.iterator();
while(itr.hasNext()) {
	Row row=itr.next();
	jsonString=jsonString+row.getString("GMM_ID")+":"+row.getString("COUNT")+",";
}
          

			LOG.info("\nWriting to GMM Count Pubusb>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>::" + jsonString);
			c.output(jsonString);
		   } catch (Exception e) {
                LOG.error("Init currentValue with zero",e);
                e.printStackTrace();
            }
		
	}
}


