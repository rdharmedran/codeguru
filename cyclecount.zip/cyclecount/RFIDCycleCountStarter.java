package com.macys.cyclecount;


import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.macys.cyclecount.async.SpannerWriteDoFn;

/**
 *
 * RFID Scanning Dataflow to read data from pubsub and write data
 *
 *
 *
 *
 *
 */
public class RFIDCycleCountStarter {

	private static final String TOTAL_COUNT_QUERY = "select InvScanHdrID,count(*) as totalCount from InvScanEpc where InvScanHdrID = @inscanHeaderId group by InvScanHdrID";

	private static final String GROUP_COUNT_QUERY = "select InvScanHdrID,count(*) as actualCount from InvScanEpc where InvScanHdrID = @inscanHeaderId and DeptNbr!=0 and VndNbr!=0  group by InvScanHdrID";

	
	private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleCountStarter.class);

	public static void main(String[] args) throws Exception {

		/* .................Loading configuration starts ................ */
		Properties configProperties = null;
		try {
			configProperties = RFIDCycleCountUtil.readPropertiesFile();
		} catch (final IOException e) {
			LOG.error("Error reading configuration file::" + e);
		}
		final PipelineOptions options = PipelineOptionsFactory.create();

		/* .................Loading configuration ends ................ */

		final String SPANNER_PROJECT_ID = configProperties.getProperty("gcp.project.id");
		final String SPANNER_INSTANCE_ID = configProperties.getProperty("spanner.instance.id");
		final String SPANNER_DATABASE_ID = configProperties.getProperty("spanner.database.id");
		final Pipeline rfidScanPipeline = Pipeline.create(options);
		LOG.info("Pipeline started");

		/* .................Schema declarations starts ................ */
		final Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
				.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN")
				.addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();

        Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")

                                        .addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN").addStringField("DEPT_NBR")

                                        .addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS")

                                        .addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("TARGET_COUNT").build();
        final Schema rfidScanGrpKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
       			.build();
    	   final Schema rfidScanGrpValueSchema = Schema.builder().addStringField("GMM_ID").addStringField("COUNT")
    	   			.build();

		final Schema notificationSchema = Schema.builder().addInt64Field("scanSessionId").addStringField("actionRequest")
				.addStringField("userId").build();

		final Schema rfidScanVendorKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
				.addStringField("DEPT_NBR").addStringField("VND_NBR").build();

		final Schema rfidScanVendorSKUCountSchema = Schema.builder().addStringField("DEPT_NBR")
				.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("INV_SCAN_GRP_ID")
				.build();
		
		final Schema rfidScanGMMKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID")
				.addStringField("DEPT_NBR").addStringField("VND_NBR").build();
		
		final Schema rfidScanGMMKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID")

				.build();
		/* .................... Schema declarations ends ................ */

		/* ................. load lookup tables starts ................ */
		@SuppressWarnings("serial")
		final
		PCollectionView<Map<String, String>> displayEpcMap = rfidScanPipeline
		.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
		.apply(Window.<Long>into(new GlobalWindows())
				.triggering(Repeatedly.forever(AfterProcessingTime.pastFirstElementInPane()))
				.discardingFiredPanes())
		.apply(ParDo.of(new DisplayTagLoader())).apply(View.<String, String>asMap());

		/* ................. load lookup tables ends ................ */
		;
		final PCollection<PubsubMessage> scanMessage = rfidScanPipeline.apply("ReadPubsub",
				PubsubIO.readMessagesWithAttributes().withIdAttribute("UNIQUE_ID")
				.fromSubscription(configProperties.getProperty("device.scan.data.subscription.name")));

		/*
		 * ---------------------------------- convert pubsub message to row object
		 * -------------------
		 */

		final PCollection<Row> scanDataRow = scanMessage.apply(ParDo.of(new PubsubMessageToRoW(rfidScanDataSchema, false)));

		/*
		 * --------------- create micro batches for message with 30 seconds
		 * window---------------
		 */

		final PCollection<Row> windowedData = scanDataRow.setCoder(RowCoder.of(rfidScanDataSchema)).apply(Window
				.<Row>into(FixedWindows.of(Duration.standardSeconds(30)))
				.triggering(AfterWatermark.pastEndOfWindow()
						.withEarlyFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(30)))
						.withLateFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(60))))
				.withAllowedLateness(Duration.standardSeconds(0), Window.ClosingBehavior.FIRE_IF_NON_EMPTY).discardingFiredPanes());

		final PCollection<Row> windowedscanData = windowedData.apply(ParDo.of(new DoFn<Row, Row>() {
			@ProcessElement
			public void processElement(ProcessContext c) {
				final String epcHex = c.element().getString("EPC_HEX");
				final long timing  = c.pane().getIndex();
				System.out.println(timing+" Attribute:: " + epcHex);
				c.output(c.element());
			}
		}));

		/*
		 * ----------------------------group the message with group
		 * id---------------------
		 */
		final PCollection<KV<String, Row>> windowedStreamData = windowedscanData.setCoder(RowCoder.of(rfidScanDataSchema))
				.apply("Set EPC Header Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
						.via(row1 -> KV.of(row1.getString("INV_SCAN_HDR_ID"), row1)))
				.setRowSchema(rfidScanDataSchema);

		final PCollection<KV<String, Iterable<Row>>> groupIdKV = windowedStreamData
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());

		/*------- remove display tag from stream using filter ----------------   */

		final PCollection<KV<String, Row>> displayremovedKV = groupIdKV.apply("FilterDisplay Tags",
				ParDo.of(new DisplayTagRemoverFn(displayEpcMap)).withSideInputs(displayEpcMap));

		final PCollection<KV<String, Iterable<Row>>> displayremovedByGroupId = displayremovedKV
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());
		// PCollection<KV<String, Long>> kvs=displayremovedKV.apply("Count occurrences
		// per scientist", Count.perKey());

		final PCollection<String> groupCount = displayremovedByGroupId.apply("Group Count", ParDo.of(new GroupCountFn()))
				.apply("Take Group Count", ParDo.of(new GroupCountToJsonFn()));
		groupCount.apply("Write Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
		;

		groupCount.apply("Write Count To Database", ParDo.of(new GroupCountToMutationFn2())).apply(
				"WriteGroupCountToHeader",
				SpannerIO.write().withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID));
		/*
		 * ------------------------ populate vendor number and department number by
		 * ---------
		 */

		final PCollection<KV<String, Row>> deptVndEnriched = displayremovedByGroupId
				.apply(ParDo.of(new DVNEnrichentFn2(configProperties)));
		deptVndEnriched.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanEpcDataSchema)));

		deptVndEnriched
		.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanEpcDataSchema)))
		.apply(GroupByKey.<String, Row>create());

		final PCollection<Row> dvnCollection = deptVndEnriched.apply(Values.<Row>create());
		
		
		
/* GMM changes goes here *************************** */
		
		final PCollection<KV<Row, Row>> rfidScanGMMEpcDataByKV = dvnCollection
				.apply("Set GMM as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
								.via(row1 -> KV.of(
										Row.withSchema(rfidScanGMMKeyEpcDataSchema)
												.addValues(row1.getString("INV_SCAN_GRP_ID"),row1.getString("INV_SCAN_HDR_ID"),row1.getString("GMM_ID"),
														row1.getString("DEPT_NBR"), row1.getString("VND_NBR"))
												.build(),
										row1)));

		final PCollection<KV<Row, Iterable<Row>>> rfidScanGMMGroupedRecords = rfidScanGMMEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanGMMKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());

		PCollection<KV<Row, Long>> gmmCountMap = rfidScanGMMGroupedRecords
				.apply("GMM Count", ParDo.of(new GMMCountFn()));
		
		

		final PCollection<KV<Row, Iterable<Long>>> gmmGroupedRecords =gmmCountMap.setCoder(KvCoder.of(RowCoder.of(rfidScanGMMKeySchema), BigEndianLongCoder.of()))
				.apply(GroupByKey.< Row,Long>create());
		PCollection<KV<Row, Iterable<Row>>> gmmCount=	gmmGroupedRecords.apply("Take GMM Count", ParDo.of(new GMMGroupToSessionFn())).setCoder(KvCoder.of(RowCoder.of(rfidScanGMMKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());;
		gmmCount.apply("convert to header level",ParDo.of(new GMMCountToJsonFn())).apply("Write GMM Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		/* department vendor count starts here .............................. */

		/*	final PCollection<KV<Row, Row>> rfidScanVendorKeyEpcDataByKV = dvnCollection
				.apply("Set DVN as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
						.via(row1 -> KV.of(
								Row.withSchema(rfidScanVendorKeyEpcDataSchema)
								.addValues(row1.getString("INV_SCAN_GRP_ID"),
										row1.getString("DEPT_NBR"), row1.getString("VND_NBR"))
								.build(),
								row1)));

		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorKeyEpcDataaGroupedRecords7 = rfidScanVendorKeyEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());

		final PCollection<String> dvnCount = rfidScanVendorKeyEpcDataaGroupedRecords7
				.apply("DVN Count", ParDo.of(new DVNCountFn()))
				.apply("Take DVN Count", ParDo.of(new DVNCountToJsonFn()));
		dvnCount.apply("Write DVN Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));

		final PCollection<KV<Row, Row>> rfidScanVendorSKUEpcDataByKV = dvnCollection.apply("Set SKU as  key",
				MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
				.via(row1 -> KV.of(Row.withSchema(rfidScanVendorSKUCountSchema)
						.addValues(row1.getString("DEPT_NBR"), row1.getString("VND_NBR"),
								row1.getString("SKU_UPC_NBR"), row1.getString("INV_SCAN_GRP_ID"))
						.build(), row1)));

		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorSKUDataaGroupedRecords7 = rfidScanVendorSKUEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorSKUCountSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());

		final PCollection<String> skuCount = rfidScanVendorSKUDataaGroupedRecords7
				.apply("DVN Count", ParDo.of(new SKUCountFn()))
				.apply("Take DVN Count", ParDo.of(new SKUCountToJsonFn()));
		skuCount.apply("Write DVN Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));

*/

		final PCollection<Mutation> mutations = deptVndEnriched.apply("CreateScanDataMutation",
				ParDo.of(new InvScanEpcToMutationFn()));
		mutations.apply("WriteScanData", ParDo.of(new SpannerWriteDoFn()));

		rfidScanPipeline
		.apply("ReadNotificationPubsub",
				PubsubIO.readStrings()
				.fromSubscription(configProperties.getProperty("submit.notification.dev")))
		.apply("JSONToRow", JsonToRow.withSchema(notificationSchema)).apply(ParDo.of(new DoFn<Row, String>() {
			private Spanner spanner = null;
			private DatabaseClient dbClient = null;

			@StartBundle
			public void startBundle(StartBundleContext c) {
				//TransactionFileOptions options =
				//c.getPipelineOptions().as(TransactionFileOptions.class);
				final com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
						.newBuilder().build();
				spanner = spannerOptions.getService();
				final String spannerProjectID = SPANNER_PROJECT_ID;
				final String spannerInstanceID = SPANNER_INSTANCE_ID;
				final String spannerDatabaseID = SPANNER_DATABASE_ID;
				final DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
				dbClient = spanner.getDatabaseClient(db);
			}

			@FinishBundle
			public void finishBundle(FinishBundleContext c) {
				dbClient = null;
				spanner.close();
			}

			@ProcessElement
			public void processElement(ProcessContext c) {
				// LOG.info("\nData from notification pubsub:::::::::" +
				// c.element().toString());
				final Row inputRow = c.element();
				final String actionRequest = inputRow.getString("actionRequest");
				final long InvScanHdrID = inputRow.getInt64("scanSessionId");
				final String userId = inputRow.getString("userId");
				if (actionRequest.equalsIgnoreCase("done")) {
					long actualCount = 0;
					long totalCount = 0;
					final Statement stmntForActualCount = Statement.newBuilder(GROUP_COUNT_QUERY)
							.bind("inscanHeaderId").to(InvScanHdrID).build();
					final ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
							.executeQuery(stmntForActualCount);
					if (resultSet.next()) {
						final Struct row = resultSet.getCurrentRowAsStruct();
						actualCount = row.getLong("actualCount");
						//LOG.info("Data::" + row.getLong("actualCount") + "::" + row.getLong("InvScanHdrID"));
					}
					resultSet.close();
					final Statement stmntForTotalCount = Statement.newBuilder(TOTAL_COUNT_QUERY)
							.bind("inscanHeaderId").to(InvScanHdrID).build();
					final ResultSet resultSetTotalCount = dbClient.singleUseReadOnlyTransaction()
							.executeQuery(stmntForTotalCount);
					if (resultSetTotalCount.next()) {
						final Struct row = resultSetTotalCount.getCurrentRowAsStruct();
						totalCount = row.getLong("totalCount");
						// LOG.info("TotalCount::" + row.getLong("totalCount") + "::"
						// + row.getLong("InvScanHdrID"));
					}
					resultSetTotalCount.close();
					final String scanSummary = "INV_SCAN_HDR_ID:" + InvScanHdrID
							+ ",MESSAGE_TYPE:scan-summary,SCAN_COUNT:" + totalCount + ",USER_ID:" + userId
							+ ",EXPECTED_ITEMS_COUNT:" + actualCount;
					// LOG.info("Publishing scan summary::" + scanSummary.toString());
	
					c.output(scanSummary);
				}
			}
		})).apply("WriteScanSummaryToPubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
		rfidScanPipeline.run().waitUntilFinish();
	}
}
