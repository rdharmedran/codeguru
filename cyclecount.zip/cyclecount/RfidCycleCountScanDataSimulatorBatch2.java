package com.macys.cyclecount;

/*
* Licensed to the Apache Software Foundation (ASF) under one
* or more contributor license agreements.  See the NOTICE file
* distributed with this work for additional information
* regarding copyright ownership.  The ASF licenses this file
* to you under the Apache License, Version 2.0 (the
* "License"); you may not use this file except in compliance
* with the License.  You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;
import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.vendor.guava.v26_0_jre.com.google.common.collect.ImmutableMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.Struct;



/**
* RFID Scanning Dataflow to read data from pubsub and write data 
 *
*
*/
public class RfidCycleCountScanDataSimulatorBatch2
{
  private static final Logger LOG = LoggerFactory.getLogger(RfidCycleCountScanDataSimulatorBatch2.class);

  public static void main(String[] args) {
                  PipelineOptions options = PipelineOptionsFactory.create();
                  Pipeline rfidScanPipeline = Pipeline.create(options);
                  LOG.info("Simulator RfidCycleCountScanDataSimulatorBatch2 started");
                  
                  /*Begin of Load Test data For Dev */
                PCollection<Struct> testData = rfidScanPipeline.apply(SpannerIO.read().withInstanceId("cspanner-storesys-np")
              .withDatabaseId("rfid-db-dev").withBatching(false)
              .withQuery("SELECT EpcHex,EpcUrn,ScanTS,SkuUpcNbr FROM EpcTestData where ZlDivnNbr=71 and  ZlStoreNbr=734 and invscanHdrId=32426 and scanTS between (SELECT TIMESTAMP(\"2020-02-24T06:25:33Z\") AS timestamp_value) and \r\n" + 
                                "(SELECT TIMESTAMP(\"2020-02-24T06:26:33Z\") AS timestamp_value) limit 100"));
                testData.apply(ParDo.of(new DoFn<Struct, PubsubMessage>(){
                                  @ProcessElement
                                  public void processElement(ProcessContext context){
                                    Struct testData =context.element();
                                    String invScanGrpId = "1097";
                                    String EPC_HEX = testData.getString("EpcHex");
                                    String invScanHdrId = "101504";
                                    String scanTS = testData.getTimestamp("ScanTS").toString();
                                    String EPC_URN = testData.getString("EpcUrn");
                                    String userId = "X000628";
                                    String skuUpc =  new Long(testData.getLong("SkuUpcNbr")).toString();
                                    String jsonString = "{\"INV_SCAN_GRP_ID\":\""+invScanGrpId+"\",\"INV_SCAN_HDR_ID\":\""+invScanHdrId+"\",\"USER_ID\":\""+userId+"\",\"EPC_HEX\":\""+EPC_HEX+"\",\"EPC_URN\":\""+EPC_URN+"\",\"SKU_UPC_NBR\":\""+skuUpc+"\",\"SCAN_TS\":\""+scanTS+"\"}";
                                    LOG.info(jsonString);
                                    PubsubMessage mesg = new PubsubMessage(jsonString.getBytes(),ImmutableMap.of("UNIQUE_ID", invScanGrpId+EPC_HEX));
                                    context.output(mesg);
                                  }
                  }))
                  //.         apply(PubsubIO.writeMessages().to("projects/mtech-storesys-np/topics/test-rfid"));
                  .apply(PubsubIO.writeMessages().to("projects/mtech-storesys-np/topics/test-rfid"));
              
                          
     rfidScanPipeline.run().waitUntilFinish();
  }
}
