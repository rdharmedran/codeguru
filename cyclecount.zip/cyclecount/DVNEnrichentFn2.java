package com.macys.cyclecount;





import java.io.IOException;

import java.util.HashMap;

import java.util.List;

import java.util.Map;

import java.util.Properties;

import java.util.stream.Collectors;

import java.util.stream.Stream;

import java.util.stream.StreamSupport;

 

import org.apache.beam.sdk.transforms.PTransform;

import org.apache.beam.sdk.transforms.View;

import org.apache.beam.sdk.schemas.Schema;

import org.apache.beam.sdk.state.MapState;

import org.apache.beam.sdk.state.ReadableState;

import org.apache.beam.sdk.state.StateSpec;

import org.apache.beam.sdk.state.StateSpecs;

import org.apache.beam.sdk.transforms.DoFn;

import org.apache.beam.sdk.transforms.DoFn.FinishBundle;

import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;

import org.apache.beam.sdk.transforms.DoFn.ProcessContext;

import org.apache.beam.sdk.transforms.DoFn.ProcessElement;

import org.apache.beam.sdk.transforms.DoFn.StartBundle;

import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;

import org.apache.beam.sdk.transforms.DoFn.StateId;

import org.apache.beam.sdk.values.KV;

import org.apache.beam.sdk.values.PCollection;

import org.apache.beam.sdk.values.PCollectionView;

import org.apache.beam.sdk.values.Row;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

 

import com.google.cloud.spanner.DatabaseClient;

import com.google.cloud.spanner.DatabaseId;

import com.google.cloud.spanner.Mutation;

import com.google.cloud.spanner.ResultSet;

import com.google.cloud.spanner.Spanner;

import com.google.cloud.spanner.Statement;

import com.google.cloud.spanner.Struct;

 

public class DVNEnrichentFn2 extends DoFn<KV<String, Iterable<Row>>, KV<String,Row>> {

                private static final Logger LOG = LoggerFactory.getLogger(DVNEnrichentFn2.class);

                private Spanner spanner = null;

                private DatabaseClient dbClient = null;

                Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")

                                                .addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN").addStringField("DEPT_NBR")

                                                .addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS")

                                                .addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("TARGET_COUNT").build();

                private Properties configProperties;

 

                public DVNEnrichentFn2(Properties configProperties) {

                                this.configProperties = configProperties;

                }

 

                @StartBundle

                public void startBundle(StartBundleContext c) {

                                // TransactionFileOptions options =

                                // c.getPipelineOptions().as(TransactionFileOptions.class);

                                com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions.newBuilder()

                                                                .build();

                                spanner = spannerOptions.getService();

                                String spannerProjectID = configProperties.getProperty("gcp.project.id");

                                String spannerInstanceID = configProperties.getProperty("spanner.instance.id");

                                String spannerDatabaseID = configProperties.getProperty("spanner.database.id");

                                DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);

                                dbClient = spanner.getDatabaseClient(db);

                }

 

                @FinishBundle

                public void finishBundle(FinishBundleContext c) {

                                try {

                                                dbClient = null;

                                                spanner.close();

                                                LOG.info("*************************Dept Vendor Enriched ************************");

                                } catch (Exception e) {

                                                LOG.error(">>>>>>>>>>>>>>>>>>>>>>>>>" + e.getMessage());

                                }

                }

 

                @ProcessElement

                public void processElement(ProcessContext c) {

                                KV<String, Iterable<Row>> keyValuepair = c.element();

                                long invScanHdrId = Long.parseLong(keyValuepair.getKey());

                                LOG.info("dv enrichment hdr id:::"+invScanHdrId);

                                Iterable<Row> inputRow = keyValuepair.getValue();

                                Stream<Row> result = StreamSupport.stream(inputRow.spliterator(), false);

                                Stream<Row> groupIdStream = StreamSupport.stream(inputRow.spliterator(), false);

                                List<String> skuUpcNbrList = result.map(entry -> entry.getString("SKU_UPC_NBR")).distinct().collect(Collectors.toList());

                                List<Long> longArrayList = skuUpcNbrList.stream().map(Long::parseLong).collect(Collectors.toList());

                                String invScanGrpIdStr = groupIdStream.map(entry -> entry.getString("INV_SCAN_GRP_ID")).distinct().collect(Collectors.toList()).get(0);

                                long invScanGrpId = Long.parseLong(invScanGrpIdStr);

                                long skuUpcNbr = 0;

                                long deptNbr = 0;

                                long vndNbr = 0;

                                long gmmId = 0;

                                String gmmName = null;

                                long targetCount = 0;

                                Map<String, String> materDataMap = new HashMap<>();

                                Statement stmtToChkDeptVnd = Statement.newBuilder("select InvScanGrpId , ps.skuupcnbr, dvn.deptnbr, dvn.vndnbr, mh.gmmId, mh.gmmName, dvn.targetCount "

                                                                + "from InvScanGrp grp "

                                                                + "join targetCntByDVN dvn on (dvn.ZlDivnNbr = grp.ZlDivnnbr and dvn.ZlStoreNbr = grp.ZlStoreNbr and dvn.CountDate = grp.CountDate) "

                                                                + "join prodsku ps on (ps.ZlDivnNbr = dvn.ZldivnNbr and ps.DeptNbr = dvn.DeptNbr and ps.VndNbr = dvn.vndnbr  and skuupcnbr in UNNEST( @skuUpcNbr) ) "

                                                                + "join mchhier mh on (mh.zldivnnbr = grp.zldivnnbr and mh.deptnbr = dvn.deptnbr and mh.activeind = 1)"

                                                                + "where grp.invscangrpid = @invScanGrpId ").bind("invScanGrpId").to(invScanGrpId).bind("skuUpcNbr")

                                                                .toInt64Array(longArrayList).build();

                                LOG.info("Statement:::::::::" + stmtToChkDeptVnd.toString());

                                ResultSet resultSet = dbClient.singleUseReadOnlyTransaction().executeQuery(stmtToChkDeptVnd);

                                // LOG.info("Statement:::::::::");

                                while (resultSet.next()) {

                                                Struct row = resultSet.getCurrentRowAsStruct();

                                           //     LOG.info("Rows>>>>>>>>>>>>>ccccccccccccccccccccccccc>>>>>>>>>>>>>:::::::::" + row);

                                                deptNbr = row.getLong("deptnbr");

                                                vndNbr = row.getLong("vndnbr");

                                                skuUpcNbr = row.getLong("skuupcnbr");

                                                gmmId = row.getLong("gmmId");

                                                gmmName = row.getString("gmmName");

                                                targetCount = row.getLong("targetCount");

                                                // LOG.info("Statement:::::::::" + skuUpcNbr);

                                                materDataMap.put(String.valueOf(skuUpcNbr), (deptNbr + "_" + vndNbr +"_" +gmmId + "_" +gmmName+"_"+targetCount));

                                              //  LOG.info("Enrichment data:::::::::" + deptNbr + "_" + vndNbr +"_" +gmmId + "_" +gmmName+"_"+targetCount);

                                }

                                resultSet.close();

                                Iterable<Row> inputRow1 = c.element().getValue();

                                Stream<Row> result1 = StreamSupport.stream(inputRow1.spliterator(), false);

                                result1.filter(entry -> entry != null).forEach(n -> c.output(KV.of(n.getString("INV_SCAN_GRP_ID"),Row.withSchema(rfidScanEpcDataSchema)

                                                                .withFieldValue("SCAN_TS", n.getString("SCAN_TS")).withFieldValue("USER_ID", n.getString("USER_ID"))

                                                                .withFieldValue("SKU_UPC_NBR", n.getString("SKU_UPC_NBR"))

                                                                .withFieldValue("EPC_URN", n.getString("EPC_URN")).withFieldValue("EPC_HEX", n.getString("EPC_HEX"))

                                                                .withFieldValue("INV_SCAN_HDR_ID", n.getString("INV_SCAN_HDR_ID"))

                                                                .withFieldValue("INV_SCAN_GRP_ID", n.getString("INV_SCAN_GRP_ID"))

                                                                .withFieldValue("DEPT_NBR",

                                                                                                materDataMap.get(n.getString("SKU_UPC_NBR")) != null

                                                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[0]

                                                                                                                                : "0")

                                                                .withFieldValue("VND_NBR",

                                                                                                materDataMap.get(n.getString("SKU_UPC_NBR")) != null

                                                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[1]

                                                                                                                                : "0")

                                                                .withFieldValue("GMM_ID",

                                                                                                materDataMap.get(n.getString("SKU_UPC_NBR")) != null

                                                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[2]

                                                                                                                                : "0")

                                                                .withFieldValue("GMM_NAME",

                                                                                                materDataMap.get(n.getString("SKU_UPC_NBR")) != null

                                                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[3]

                                                                                                                                : "0")

                                                                .withFieldValue("TARGET_COUNT",

                                                                                                materDataMap.get(n.getString("SKU_UPC_NBR")) != null

                                                                                                                                ? materDataMap.get(n.getString("SKU_UPC_NBR")).split("_")[4]

                                                                                                                                : "0")

                                                                .build())));

                                materDataMap.clear();

                                // LOG.info("DeptVendor jsonString : ");

                }

 

}