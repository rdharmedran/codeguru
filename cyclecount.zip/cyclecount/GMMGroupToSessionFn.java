package com.macys.cyclecount;

import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GMMGroupToSessionFn extends DoFn<KV<Row, Iterable<Long>>,KV<Row, Row>> {
	private static final Logger LOG = LoggerFactory.getLogger(GMMGroupToSessionFn.class);
	   final Schema rfidScanGrpKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
   			.build();
	   final Schema rfidScanGrpValueSchema = Schema.builder().addStringField("GMM_ID").addStringField("COUNT")
	   			.build();
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	@ProcessElement
	public void processElement(ProcessContext c) {
		try {
			
			Long sum =  StreamSupport.stream(c.element().getValue().spliterator(), false)
					  .collect(Collectors.summingLong(Long::longValue));

			 LOG.info(sum + "<>........cccccccccccccccccccccccccccc...............=<>" + sum);
			
			final Row keyRow = Row.withSchema(rfidScanGrpKeySchema)
					 .withFieldValue("INV_SCAN_GRP_ID", c.element().getKey().getString("INV_SCAN_GRP_ID"))
					.withFieldValue("INV_SCAN_HDR_ID", c.element().getKey().getString("INV_SCAN_HDR_ID")).build();
			
			final Row valueRow = Row.withSchema(rfidScanGrpValueSchema)
					 .withFieldValue("GMM_ID", c.element().getKey().getString("GMM_ID"))
					.withFieldValue("COUNT", String.valueOf(sum)).build();
			c.output(KV.of( keyRow, valueRow));
			
		} catch (final Exception e) {
			LOG.error("Init currentValue with zero",e);
		}

	}
}


