package com.macys.cyclecount;

import java.io.IOException;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.sdk.transforms.PTransform;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.DoFn.StateId;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;

public class DVNCountFn
 extends DoFn<KV<Row, Iterable<Row>>, KV<String, Long>> {
	private static final Logger LOG = LoggerFactory.getLogger(DVNCountFn.class);
	private static final String DISPLAY_TAG_QUERY = "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733  and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ";

	@StateId("Value")
	private final StateSpec<MapState<String, Long>> mapState = StateSpecs.map();

	@ProcessElement
	public void processElement(ProcessContext context, @StateId("Value") MapState<String, Long> valueState) {
		try {
			KV<Row, Iterable<Row>> element = context.element();
			final Row key = context.element().getKey();
            final String keyString=key.getString("INV_SCAN_GRP_ID")+"_"+key.getString("DEPT_NBR")+"_"+ key.getString("VND_NBR");
			ReadableState<Long> letterSumState = valueState.get(keyString);
			long currentSum = letterSumState.read() != null ? letterSumState.read() : 0;
			final Iterable<Row> inputRow = context.element().getValue();
			final long count = StreamSupport.stream(inputRow.spliterator(), false).count();
		
			long letterSum = currentSum + count;
			valueState.put(keyString, letterSum);
			//LOG.info(keyString + "<>=" + valueState.get(keyString).read());
			//LOG.info(keyString + "<>=<>" + count);
			context.output(KV.of(keyString, letterSum));

		} catch (Exception e) {
			LOG.error("Init currentValue with zero", e);
		}
		// LOG.info("message: "+message);
		// LOG.info(message.getKey()+"="+currentValue);

		// valueState.write( KV.of(message.getKey(),currentValue));
	}

}
