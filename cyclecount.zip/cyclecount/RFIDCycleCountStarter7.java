package com.macys.cyclecount;

/*

* Licensed to the Apache Software Foundation (ASF) under one

* or more contributor license agreements.  See the NOTICE file

* distributed with this work for additional information

* regarding copyright ownership.  The ASF licenses this file

* to you under the Apache License, Version 2.0 (the

* "License"); you may not use this file except in compliance

* with the License.  You may obtain a copy of the License at

*

*     http://www.apache.org/licenses/LICENSE-2.0

*

* Unless required by applicable law or agreed to in writing, software

* distributed under the License is distributed on an "AS IS" BASIS,

* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

* See the License for the specific language governing permissions and

* limitations under the License.

*/
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import org.apache.beam.runners.dataflow.DataflowRunner;
import org.apache.beam.runners.dataflow.options.DataflowPipelineOptions;
import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.BigIntegerCoder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.coders.StringUtf8Coder;
import org.apache.beam.sdk.coders.VarLongCoder;
import org.apache.beam.sdk.extensions.sql.SqlTransform;
import org.apache.beam.sdk.extensions.sql.meta.provider.pubsub.PubsubMessageToRow;
import org.apache.beam.sdk.io.AvroIO;
import org.apache.beam.sdk.io.GenerateSequence;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubIO;
import org.apache.beam.sdk.io.gcp.pubsub.PubsubMessage;

import org.apache.beam.sdk.io.gcp.spanner.SpannerIO;
import org.apache.beam.sdk.io.redis.RedisIO;
import org.apache.beam.sdk.options.PipelineOptions;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.state.ValueState;
import org.apache.beam.sdk.transforms.Combine;
import org.apache.beam.sdk.transforms.Count;
import org.apache.beam.sdk.transforms.Deduplicate;
import org.apache.beam.sdk.transforms.Distinct;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.GroupByKey;
import org.apache.beam.sdk.transforms.JsonToRow;
import org.apache.beam.sdk.transforms.MapElements;
import org.apache.beam.sdk.transforms.ParDo;
import org.apache.beam.sdk.transforms.Values;
import org.apache.beam.sdk.transforms.View;
import org.apache.beam.sdk.transforms.Wait;
import org.apache.beam.sdk.transforms.join.CoGbkResult;
import org.apache.beam.sdk.transforms.join.CoGroupByKey;
import org.apache.beam.sdk.transforms.join.KeyedPCollectionTuple;
import org.apache.beam.sdk.transforms.DoFn.FinishBundle;
import org.apache.beam.sdk.transforms.DoFn.FinishBundleContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessContext;
import org.apache.beam.sdk.transforms.DoFn.ProcessElement;
import org.apache.beam.sdk.transforms.DoFn.StartBundle;
import org.apache.beam.sdk.transforms.DoFn.StartBundleContext;
import org.apache.beam.sdk.transforms.Flatten;
import org.apache.beam.sdk.transforms.windowing.AfterFirst;
import org.apache.beam.sdk.transforms.windowing.AfterPane;
import org.apache.beam.sdk.transforms.windowing.AfterProcessingTime;
import org.apache.beam.sdk.transforms.windowing.AfterWatermark;
import org.apache.beam.sdk.transforms.windowing.CalendarWindows;
import org.apache.beam.sdk.transforms.windowing.FixedWindows;
import org.apache.beam.sdk.transforms.windowing.GlobalWindows;
import org.apache.beam.sdk.transforms.windowing.Repeatedly;
import org.apache.beam.sdk.transforms.windowing.Trigger;
import org.apache.beam.sdk.transforms.windowing.Window;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.PCollection;
import org.apache.beam.sdk.values.PCollectionTuple;
import org.apache.beam.sdk.values.PCollectionView;
import org.apache.beam.sdk.values.PDone;
import org.apache.beam.sdk.values.Row;
import org.apache.beam.sdk.values.TupleTag;
import org.apache.beam.sdk.values.TypeDescriptors;
import org.joda.time.DateTimeZone;
import org.joda.time.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.cloud.spanner.DatabaseClient;
import com.google.cloud.spanner.DatabaseId;
import com.google.cloud.spanner.Mutation;
import com.google.cloud.spanner.ResultSet;
import com.google.cloud.spanner.Spanner;
import com.google.cloud.spanner.Statement;
import com.google.cloud.spanner.Struct;
import com.google.common.collect.MapMaker;
import com.macys.cyclecount.async.SpannerWriteDoFn;

/**
 * 
 * RFID Scanning Dataflow to read data from pubsub and write data
 *
 *
 * 
 * 
 * 
 */
public class RFIDCycleCountStarter7 {
	private static final String GROUP_COUNT_SQL = "select epc.InvScanHdrID, count(1) as groupCount from InvScanEpc epc , invscanhdr hdr where  hdr.invScanhdrId = epc.invscanhdrid and hdr.invscanhdrstatus = 'Scanning'  group by epc.InvScanHdrID";

	private static final String TOTAL_COUNT_QUERY = "select InvScanHdrID,count(*) as totalCount from InvScanEpc where InvScanHdrID = @inscanHeaderId group by InvScanHdrID";

	private static final String GROUP_COUNT_QUERY = "select InvScanHdrID,count(*) as actualCount from InvScanEpc where InvScanHdrID = @inscanHeaderId   group by InvScanHdrID";

	private static final String DISPLAY_TAG_QUERY = "Select tw.ZlDivnNbr,tw.ZlStorenbr,  tw.EpcHex from tagswritten tw  Where tw.ActiveFlag = 'A' and tw.zldivnnbr = 71 and TW.zlstorenbr = 733  and (tw.ZoneName ) in (Select  zn.ZoneName from RfidZone zn Where zn.ZoneType = 'Audit' and tw.ZlDivnNbr =  zn.ZlDivnNbr and zn.ZlStorenbr = tw.ZlStorenbr)  ";

	private static final String DVN_LOOKUP_QUERY = "select InvScanGrpId , ps.skuupcnbr, dvn.deptnbr, dvn.vndnbr from InvScanGrp grp join targetCntByDVN dvn on (dvn.ZlDivnNbr = grp.ZlDivnnbr and dvn.ZlStoreNbr = grp.ZlStoreNbr and dvn.CountDate = grp.CountDate) join prodsku ps on (ps.ZlDivnNbr = dvn.ZldivnNbr and ps.DeptNbr = dvn.DeptNbr and ps.VndNbr = dvn.vndnbr  and skuupcnbr in UNNEST( @skuUpcNbr) ) where grp.invscangrpid = @invScanGrpId ";

	private static final Logger LOG = LoggerFactory.getLogger(RFIDCycleCountStarter7.class);

	public static void main(String[] args) throws Exception {

		/* .................Loading configuration starts ................ */
		Properties configProperties = null;
		try {
			configProperties = RFIDCycleCountUtil.readPropertiesFile();
		} catch (IOException e) {
			LOG.error("Error reading configuration file::" + e);
		}
		PipelineOptions options = PipelineOptionsFactory.create();

		/* .................Loading configuration ends ................ */

		final String SPANNER_PROJECT_ID = configProperties.getProperty("gcp.project.id");
		final String SPANNER_INSTANCE_ID = configProperties.getProperty("spanner.instance.id");
		final String SPANNER_DATABASE_ID = configProperties.getProperty("spanner.database.id");
		Pipeline rfidScanPipeline = Pipeline.create(options);
		LOG.info("Pipeline started");

		/* .................Schema declarations starts ................ */
		Schema rfidScanDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")
				.addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN")
				.addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();
		
	     Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID")

                 .addStringField("USER_ID").addStringField("EPC_HEX").addStringField("EPC_URN").addStringField("DEPT_NBR")

                 .addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("SCAN_TS")

                 .addStringField("GMM_ID").addStringField("GMM_NAME").addStringField("TARGET_COUNT").build();
		
//		Schema rfidScanEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
//				.addStringField("INV_SCAN_HDR_ID").addStringField("USER_ID").addStringField("EPC_HEX")
//				.addStringField("EPC_URN").addStringField("DEPT_NBR").addStringField("VND_NBR")
//				.addStringField("SKU_UPC_NBR").addStringField("SCAN_TS").build();

		Schema notificationSchema = Schema.builder().addInt64Field("scanSessionId").addStringField("actionRequest")
				.addStringField("userId").build();

		final Schema rfidScanVendorKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID")
				.addStringField("DEPT_NBR").addStringField("VND_NBR").build();
		
		final Schema rfidScanGMMKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("GMM_ID")
				.addStringField("DEPT_NBR").addStringField("VND_NBR").build();
		
		final Schema rfidScanGMMKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("GMM_ID")
				.build();
		final Schema test = Schema.builder().addStringField("INV_SCAN_HDR_ID")
				.addStringField("count").build();
		final Schema rfidScanVendorSKUCountSchema = Schema.builder().addStringField("DEPT_NBR")
				.addStringField("VND_NBR").addStringField("SKU_UPC_NBR").addStringField("INV_SCAN_GRP_ID")
				.build();
		/* .................... Schema declarations ends ................ */

		/* ................. load lookup tables starts ................ */
		 DateTimeZone timeZone = DateTimeZone.forID("America/Los_Angeles");
		CalendarWindows.DaysWindows daysWindow =
			    CalendarWindows.days(5).withStartingDay(1990, 1, 1).withTimeZone(timeZone);
		@SuppressWarnings("serial")
		PCollectionView<Map<String, String>> displayEpcMap = rfidScanPipeline
				.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
				.apply(Window.<Long>into(daysWindow)
						.discardingFiredPanes())
				.apply(ParDo.of(new DisplayTagLoader())).apply(View.<String, String>asMap());

		/* ................. load lookup tables ends ................ */
		;
		PCollection<PubsubMessage> scanMessage = rfidScanPipeline.apply("ReadPubsub",
				PubsubIO.readMessagesWithAttributes().withIdAttribute("UNIQUE_ID")
						.fromSubscription(configProperties.getProperty("device.scan.data.subscription.name.qa")));

		/*
		 * ---------------------------------- convert pubsub message to row object
		 * -------------------
		 */

		PCollection<Row> scanDataRow = scanMessage.apply(ParDo.of(new PubsubMessageToRoW(rfidScanDataSchema, false)));

		/*
		 * --------------- create micro batches for message with 30 seconds
		 * window---------------
		 */
		final PCollection<Row> windowedData = scanDataRow.setCoder(RowCoder.of(rfidScanDataSchema)).apply(Window
				.<Row>into(FixedWindows.of(Duration.standardSeconds(60)))
				.withAllowedLateness(Duration.standardSeconds(5), Window.ClosingBehavior.FIRE_ALWAYS)
				.discardingFiredPanes());
	

		PCollection<Row> windowedscanData = windowedData.apply((ParDo.of(new DoFn<Row, Row>() {
			@ProcessElement
			public void processElement(ProcessContext c) {
				String epcHex = c.element().getString("EPC_HEX");
				 long timing  = c.pane().getIndex();
				System.out.println(timing+" Attribute:: " + epcHex);
				c.output(c.element());
			}
		})));

		/*
		 * ----------------------------group the message with group
		 * id---------------------
		 */
		PCollection<KV<String, Row>> windowedStreamData = windowedscanData.setCoder(RowCoder.of(rfidScanDataSchema))
				.apply("Set EPC Header Id as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.rows()))
								.via(row1 -> KV.of(((Row) row1).getString("INV_SCAN_HDR_ID"), row1)))
				.setRowSchema(rfidScanDataSchema);

		PCollection<KV<String, Iterable<Row>>> groupIdKV = windowedStreamData
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());

		/*------- remove display tag from stream using filter ----------------   */

		PCollection<KV<String, Row>> displayremovedKV = groupIdKV.apply("FilterDisplay Tags",
				ParDo.of(new DisplayTagRemoverFn(displayEpcMap)).withSideInputs(displayEpcMap));

		PCollection<KV<String, Iterable<Row>>> displayremovedByGroupId = displayremovedKV
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanDataSchema)))
				.apply(GroupByKey.<String, Row>create());
		// PCollection<KV<String, Long>> kvs=displayremovedKV.apply("Count occurrences
		// per scientist", Count.perKey());

		PCollection<String> groupCount = displayremovedByGroupId.apply("Group Count", ParDo.of(new GroupCountFn()))
				.apply("Take Group Count", ParDo.of(new GroupCountToJsonFn()));
		groupCount.apply("Write Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
		;

		groupCount.apply("Write Count To Database", ParDo.of(new GroupCountToMutationFn2())).apply(
				"WriteGroupCountToHeader",
				SpannerIO.write().withInstanceId(SPANNER_INSTANCE_ID).withDatabaseId(SPANNER_DATABASE_ID));
		
//		
//		PCollection<KV<String, String>> windowedStreamData1 = windowedscanData
//				.apply("Set EPC Header Id as  key",
//						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.strings(), TypeDescriptors.strings()))
//								.via(row1 -> KV.of(("Grp_Count"+((Row) row1).getString("INV_SCAN_HDR_ID")), row1.toString())))
//				;
		
//		windowedStreamData1.apply(RedisIO.write().withEndpoint("127.0.0.1", 6379));
//		
//		PCollection<KV<String, String>> read =
//				rfidScanPipeline.apply(
//		            "Read",
//		            RedisIO.read()
//		            .withEndpoint("127.0.0.1", 6379)
//		                .withKeyPattern("Grp_Count*"));
//		
//		read.apply((ParDo.of(new DoFn<KV<String, String>, Void>() {
//				@ProcessElement
//				public void processElement(ProcessContext c) {
//					String epcHex = c.element().getValue();
//					 long timing  = c.pane().getIndex();
//					System.out.println(timing+" epcHex:: " + epcHex);
//					//c.output(c.element());
//				}
//			})));
		/*
		 * ------------------------ populate vendor number and department number by
		 * ---------
		 */

		PCollection<KV<String, Row>> deptVndEnriched = displayremovedByGroupId
				.apply(ParDo.of(new DVNEnrichentFn(configProperties)));
		deptVndEnriched.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanEpcDataSchema)));

		PCollection<KV<String, Iterable<Row>>> deptVndEnrichedByGroupId = deptVndEnriched
				.setCoder(KvCoder.of(StringUtf8Coder.of(), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<String, Row>create());

		PCollection<Row> dvnCollection = deptVndEnriched.apply(Values.<Row>create());

		/* department vendor count starts here .............................. */
		
		/* GMM changes goes here *************************** */
		
		final PCollection<KV<Row, Row>> rfidScanGMMEpcDataByKV = dvnCollection
				.apply("Set DVN as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
								.via(row1 -> KV.of(
										Row.withSchema(rfidScanGMMKeyEpcDataSchema)
												.addValues(row1.getString("INV_SCAN_GRP_ID"),row1.getString("GMM_ID"),
														row1.getString("DEPT_NBR"), row1.getString("VND_NBR"))
												.build(),
										row1)));

		final PCollection<KV<Row, Iterable<Row>>> rfidScanGMMGroupedRecords = rfidScanGMMEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanGMMKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());

		PCollection<KV<Row, Long>> gmmCountMap = rfidScanGMMGroupedRecords
				.apply("GMM Count", ParDo.of(new GMMCountFn()));
		
		

		final PCollection<KV<Row, Iterable<Long>>> gmmGroupedRecords =gmmCountMap.setCoder(KvCoder.of(RowCoder.of(rfidScanGMMKeySchema), BigEndianLongCoder.of()))
				.apply(GroupByKey.< Row,Long>create());
		PCollection<String> gmmCount=	gmmGroupedRecords.apply("Take DVN Count", ParDo.of(new GMMGroupToSessionFn()));
		gmmCount.apply("Write DVN Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
		
		
		
		
		
		
		

		final PCollection<KV<Row, Row>> rfidScanVendorKeyEpcDataByKV = dvnCollection
				.apply("Set DVN as  key",
						MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
								.via(row1 -> KV.of(
										Row.withSchema(rfidScanVendorKeyEpcDataSchema)
												.addValues(row1.getString("INV_SCAN_GRP_ID"),
														row1.getString("DEPT_NBR"), row1.getString("VND_NBR"))
												.build(),
										row1)));

		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorKeyEpcDataaGroupedRecords7 = rfidScanVendorKeyEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanGMMKeyEpcDataSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());

		PCollection<String> dvnCount = rfidScanVendorKeyEpcDataaGroupedRecords7
				.apply("DVN Count", ParDo.of(new DVNCountFn()))
				.apply("Take DVN Count", ParDo.of(new DVNCountToJsonFn()));
		dvnCount.apply("Write DVN Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));

		final PCollection<KV<Row, Row>> rfidScanVendorSKUEpcDataByKV = dvnCollection.apply("Set SKU as  key",
				MapElements.into(TypeDescriptors.kvs(TypeDescriptors.rows(), TypeDescriptors.rows()))
						.via(row1 -> KV.of(Row.withSchema(rfidScanVendorSKUCountSchema)
								.addValues(row1.getString("DEPT_NBR"), row1.getString("VND_NBR"),
										row1.getString("SKU_UPC_NBR"), row1.getString("INV_SCAN_GRP_ID"))
								.build(), row1)));

		final PCollection<KV<Row, Iterable<Row>>> rfidScanVendorSKUDataaGroupedRecords7 = rfidScanVendorSKUEpcDataByKV
				.setCoder(KvCoder.of(RowCoder.of(rfidScanVendorSKUCountSchema), RowCoder.of(rfidScanEpcDataSchema)))
				.apply(GroupByKey.<Row, Row>create());
		
		PCollection<String> skuCount = rfidScanVendorSKUDataaGroupedRecords7
				.apply("DVN Count", ParDo.of(new SKUCountFn()))
				.apply("Take DVN Count", ParDo.of(new SKUCountToJsonFn()));
		skuCount.apply("Write DVN Count To Pubsub",
				PubsubIO.writeStrings().to(configProperties.getProperty("group.count.topic.name")));
		
		

		PCollection<Mutation> mutations = deptVndEnriched.apply("CreateScanDataMutation",
				ParDo.of(new InvScanEpcToMutationFn()));
		mutations.apply("WriteScanData", ParDo.of(new SpannerWriteDoFn()));

	PCollection< KV<String,Long>> callEvents=	rfidScanPipeline
				.apply("ReadNotificationPubsub",
						PubsubIO.readStrings()
								.fromSubscription(configProperties.getProperty("device.scan.data.subscription.name")))
				
				.apply(Window.<String>into(FixedWindows.of(Duration.standardSeconds(60))).triggering(AfterWatermark.pastEndOfWindow()
						.withEarlyFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(0)))
						.withLateFirings(
								AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(0))))
						.withAllowedLateness(Duration.standardSeconds(0)).discardingFiredPanes()).apply(ParDo.of(new DoFn<String,  KV<String,Long>>() {
					private Spanner spanner = null;
					private DatabaseClient dbClient = null;

					@StartBundle
					public void startBundle(StartBundleContext c) {
//TransactionFileOptions options =
//c.getPipelineOptions().as(TransactionFileOptions.class);
						com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
								.newBuilder().build();
						spanner = spannerOptions.getService();
						String spannerProjectID = SPANNER_PROJECT_ID;
						String spannerInstanceID = SPANNER_INSTANCE_ID;
						String spannerDatabaseID = SPANNER_DATABASE_ID;
						DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
						dbClient = spanner.getDatabaseClient(db);
					}

					@FinishBundle
					public void finishBundle(FinishBundleContext c) {
						dbClient = null;
						spanner.close();
					}

					@ProcessElement
					public void processElement(ProcessContext c) {
						// LOG.info("\nData from notification pubsub:::::::::" +
						// c.element().toString());
					
							long actualCount = 0;
							long totalCount = 0;
							Statement stmntForActualCount = Statement.newBuilder(GROUP_COUNT_QUERY)
									.bind("inscanHeaderId").to(101758).build();
							ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
									.executeQuery(stmntForActualCount);
							if (resultSet.next()) {
								Struct row = resultSet.getCurrentRowAsStruct();
								actualCount = row.getLong("actualCount");
								
								
								c.output(KV.of("101758", actualCount));
LOG.info("Data::" + row.getLong("actualCount") + "::" + row.getLong("InvScanHdrID"));
							}
							resultSet.close();
						
						
					}
				}));
	PCollection< KV<String,Long>> stations=	rfidScanPipeline 
		.apply(GenerateSequence.from(0).withRate(1, Duration.standardSeconds(3600L)))
		.apply(Window.<Long>into(FixedWindows.of(Duration.standardSeconds(60))).triggering(AfterWatermark.pastEndOfWindow()
				.withEarlyFirings(
						AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(0)))
				.withLateFirings(
						AfterProcessingTime.pastFirstElementInPane().plusDelayOf(Duration.standardSeconds(0))))
				.withAllowedLateness(Duration.standardSeconds(0)).discardingFiredPanes())
				
		.apply(ParDo.of(new DoFn<Long,  KV<String,Long>>() {
			private Spanner spanner = null;
			private DatabaseClient dbClient = null;

			@StartBundle
			public void startBundle(StartBundleContext c) {
//TransactionFileOptions options =
//c.getPipelineOptions().as(TransactionFileOptions.class);
				com.google.cloud.spanner.SpannerOptions spannerOptions = com.google.cloud.spanner.SpannerOptions
						.newBuilder().build();
				spanner = spannerOptions.getService();
				String spannerProjectID = SPANNER_PROJECT_ID;
				String spannerInstanceID = SPANNER_INSTANCE_ID;
				String spannerDatabaseID = SPANNER_DATABASE_ID;
				DatabaseId db = DatabaseId.of(spannerProjectID, spannerInstanceID, spannerDatabaseID);
				dbClient = spanner.getDatabaseClient(db);
			}

			@FinishBundle
			public void finishBundle(FinishBundleContext c) {
				dbClient = null;
				spanner.close();
			}

			@ProcessElement
			public void processElement(ProcessContext c) {
				// LOG.info("\nData from notification pubsub:::::::::" +
				// c.element().toString());
				//Row inputRow = c.element();
				
					long actualCount = 0;
					long totalCount = 0;
					Statement stmntForActualCount = Statement.newBuilder(TOTAL_COUNT_QUERY)
							.bind("inscanHeaderId").to(101758).build();
					ResultSet resultSet = dbClient.singleUseReadOnlyTransaction()
							.executeQuery(stmntForActualCount);
					if (resultSet.next()) {
						Struct row = resultSet.getCurrentRowAsStruct();
						actualCount = row.getLong("totalCount");
						
					//	Object InvScanHdrID=row.getString("InvScanHdrID");
						c.output(KV.of("101758", actualCount));
						System.out.println(row.getLong("totalCount"));		
//LOG.info("Data::" + row.getLong("actualCount") + "::" + row.getLong("InvScanHdrID"));
					}
					resultSet.close();
				
				}
			
		}));
	final PCollection<KV<String, CoGbkResult>> groupResult =KeyedPCollectionTuple.of("ss", callEvents)
    .and("uu", stations)
    // group auctions and persons by personId
    .apply(CoGroupByKey.create());
	        
	groupResult.apply((ParDo.of(new DoFn<KV<String, CoGbkResult>, Void>() {
				@ProcessElement
				public void processElement(ProcessContext c) {
					CoGbkResult epcHex = c.element().getValue();
					 long timing  = c.pane().getIndex();
					System.out.println(c.element().getKey()+" count:: " + epcHex.toString());
					System.out.println(c.element().getKey()+" count:: " + epcHex.getOnly("uu").toString());
				//	c.output(c.element());
				}
			})));

		rfidScanPipeline.run().waitUntilFinish();
	}
}
