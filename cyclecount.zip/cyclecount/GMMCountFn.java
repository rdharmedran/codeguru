package com.macys.cyclecount;

import java.util.stream.StreamSupport;

import org.apache.beam.sdk.coders.BigEndianLongCoder;
import org.apache.beam.sdk.coders.KvCoder;
import org.apache.beam.sdk.coders.RowCoder;
import org.apache.beam.sdk.schemas.Schema;
import org.apache.beam.sdk.state.MapState;
import org.apache.beam.sdk.state.ReadableState;
import org.apache.beam.sdk.state.StateSpec;
import org.apache.beam.sdk.state.StateSpecs;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.values.KV;
import org.apache.beam.sdk.values.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GMMCountFn extends DoFn<KV<Row, Iterable<Row>>, KV<Row, Long>> {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Logger LOG = LoggerFactory.getLogger(GMMCountFn.class);
	final Schema rfidScanGMMKeySchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID")
			.build();
	final Schema rfidScanGMMKeyEpcDataSchema = Schema.builder().addStringField("INV_SCAN_GRP_ID").addStringField("INV_SCAN_HDR_ID").addStringField("GMM_ID")
			.addStringField("DEPT_NBR").addStringField("VND_NBR").build();
	@StateId("Value")
	private final StateSpec<MapState<Row, Long>> mapState = StateSpecs.map(RowCoder.of(rfidScanGMMKeyEpcDataSchema), BigEndianLongCoder.of());

	@ProcessElement
	public void processElement(ProcessContext context, @StateId("Value") MapState<Row, Long> valueState) {
		try {
			final Row key = context.element().getKey();
			final ReadableState<Long> letterSumState = valueState.get(key);
			final long remainingCount = letterSumState.read() != null ? letterSumState.read() : 0;
			final Iterable<Row> inputRow = context.element().getValue();
			final long count = StreamSupport.stream(inputRow.spliterator(), false).count();
			final Row valueRow = inputRow.iterator().next();
			final long targetCount = Long.parseLong(valueRow.getString("TARGET_COUNT"));
			final long letterSum = targetCount - (remainingCount + count);
			valueState.put(key, letterSum);
			// LOG.info(keyString + "<>=" + valueState.get(keyString).read());
			 LOG.info(valueRow + "<>.......................=<>" + count);


			final Row keyRow = Row.withSchema(rfidScanGMMKeySchema)
					 .withFieldValue("INV_SCAN_GRP_ID", key.getString("INV_SCAN_GRP_ID"))
					.withFieldValue("INV_SCAN_HDR_ID", key.getString("INV_SCAN_HDR_ID"))
					.withFieldValue("GMM_ID",key.getString("GMM_ID")).build();
			context.output(KV.of( keyRow, letterSum));

		} catch  (Exception e) {
			LOG.error("Init currentValue with zero", e);
		}
		// LOG.info("message: "+message);
		// LOG.info(message.getKey()+"="+currentValue);

		// valueState.write( KV.of(message.getKey(),currentValue));
	}

}
